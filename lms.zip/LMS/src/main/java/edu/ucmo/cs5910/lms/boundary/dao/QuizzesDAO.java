package edu.ucmo.cs5910.lms.boundary.dao;

import org.springframework.stereotype.Repository;

@Repository
public class QuizzesDAO {

}
