package edu.ucmo.cs5910.lms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.ucmo.cs5910.lms.boundary.dao.CourseInfoDAO;
import edu.ucmo.cs5910.lms.entity.CourseInfo;

/**
 * 
 */
@Service
public class CourseInfoMgr {
    @Autowired
    private CourseInfoDAO courseInfoDao;

    public CourseInfo getCourseInfo(int argClassId) {
        return courseInfoDao.getCourseInfo(argClassId);
    }

}
