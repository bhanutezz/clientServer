/*
 * Class: edu.ucmo.cs5910.lms.model.UserType
 */
package edu.ucmo.cs5910.lms.model;

/**
 * 
 */
public enum UserType
{
    STUDENT, INSTRUCTOR

}
